//
//  ViewController.swift
//  demoRelationship
//
//  Created by INDRAVADAN SHRIMALI on 2018-03-18.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tblView: UITableView!
    //MARK: - Coredat Stuff
    
    let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var category = [Categories]()
    
    func saveData(){
        
        do{
           try myContext.save()
        }
        
        catch{
            print("Error : \(error)")
        }
    }
    

    func loadData(){
        
        let request : NSFetchRequest<Categories> = Categories.fetchRequest()
        
        
        
        do{
          category =  try myContext.fetch(request)
        }
            
        catch{
            print("Error : \(error)")
        }
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Categories"
        
        self.navigationItem.hidesBackButton = true;
        
        loadData()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    
    @IBAction func btnLogoutTapped(_ sender: UIBarButtonItem) {
        
        self.navigationController!.popToRootViewController(animated: true)
    }
    
    
    @IBAction func btnAddTapped(_ sender: UIBarButtonItem) {
        
        let alertController = UIAlertController(title: "Alert", message: "Enter Movie Category", preferredStyle: .alert)
        
        alertController.addTextField();
        
        // make a button for the alertbox
        let okButton = UIAlertAction(title: "OK", style: .default, handler: {
            action in
            
            let item = alertController.textFields?[0].text
            
            // print(item)
            
            // logic: add your movie to the database and array
            
            // create a new movie object
            let cat = Categories(context: self.myContext)
            
            // set the movie object's properties
            cat.name = item
            
            
            
            // add to the array
            self.category.append(cat)
            
            // save the movies object
            self.saveData()
            
            // ui: refresh the table
            self.tblView.reloadData()
            
        })
        
        let cancelButton = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        
        // add the button to the alertbox
        alertController.addAction(okButton)
        alertController.addAction(cancelButton)
        
        // show the alert box
        self.present(alertController, animated: true)
        
        
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let dest = segue.destination as! SecondVC
        
        let index = tblView.indexPathForSelectedRow
        
        if index != nil {
            
            dest.genre = category[index!.row]
        }
        
       // print( "Genre Is !!!!!!!!!!! :\( dest.genre!)")
    }
    
    
    
    
    
    //MARK:- Tableview Methods
    
    // MARK: - Tableview Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return category.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = category[indexPath.row].name
        
        
        return cell
        
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        print(indexPath.row)
        
        // show what's actually in the row
        print(category[indexPath.row])
        
        
      //  self.performSegue(withIdentifier: "MoviesVC", sender: self)
        
        
        
        self.performSegue(withIdentifier: "SecondVC", sender: self)
        
        saveData()
        tblView.reloadData()
    }
    
    
    // delete a row of the table
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            print("going to delete!")
            
            // LOGIC: delete it from DB and ARRAY
            
            // delete it from DB
            //  - do the delete
            myContext.delete(category[indexPath.row])
            //  - save YOUR CHANGES!!!!!!!!!!!
            saveData()
            
            // delete it from the array
            category.remove(at: indexPath.row)
            
            // UI: delete it from the tableView
            tblView.deleteRows(at: [indexPath], with: .automatic)
            
        }
        
        
        
        
        
    }
    


}

