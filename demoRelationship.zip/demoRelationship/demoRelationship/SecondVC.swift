//
//  SecondVC.swift
//  demoRelationship
//
//  Created by INDRAVADAN SHRIMALI on 2018-03-18.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit
import CoreData

class SecondVC: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    
    @IBOutlet weak var tblView: UITableView!
    
    
    //MARK: - Coredat Stuff
    
    let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var movie = [Movies]()
    
    var genre : Categories?
    
    func saveData(){
        
        do{
            try myContext.save()
        }
            
        catch{
            print("Error : \(error)")
        }
    }
    
    
    func loadData(){
        
        let request : NSFetchRequest<Movies> = Movies.fetchRequest()
        let query = NSPredicate(format: "category.name MATCHES %@", (genre!.name!))
        request.predicate = query
        
        
        
        do{
            movie =  try myContext.fetch(request)
        }
            
        catch{
            print("Error : \(error)")
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Movies"
        loadData()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func btnAddTapped(_ sender: UIBarButtonItem) {
        
        let alertController = UIAlertController(title: "Alert", message: "Enter Movie Category", preferredStyle: .alert)
        
        alertController.addTextField();
        
        // make a button for the alertbox
        let okButton = UIAlertAction(title: "OK", style: .default, handler: {
            action in
            
            let item = alertController.textFields?[0].text
            
            // print(item)
            
            // logic: add your movie to the database and array
            
            // create a new movie object
            let mov = Movies(context: self.myContext)
            
            // set the movie object's properties
            mov.name = item
            mov.isSeen = false
            mov.category = self.genre
            
            print(self.genre as Any)
            print(mov.category as Any)
            
            
            // add to the array
            self.movie.append(mov)
            
            // save the movies object
            self.saveData()
            
            // ui: refresh the table
            self.tblView.reloadData()
            
        })
        
        let cancelButton = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        
        // add the button to the alertbox
        alertController.addAction(okButton)
        alertController.addAction(cancelButton)
        
        // show the alert box
        self.present(alertController, animated: true)
        
    }
    
    
    
    
    
    
    // MARK: - Tableview Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return movie.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = movie[indexPath.row].name
        cell.detailTextLabel?.text = String(movie[indexPath.row].isSeen)
        
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        print(indexPath.row)
        
        // show what's actually in the row
        print(movie[indexPath.row])
        let m = movie[indexPath.row];
        if m.isSeen == true{
            m.isSeen = false
        }
        else
        {
            m.isSeen = true
        }
        
        saveData()
        
        self.tblView.reloadData()
        
       // self.performSegue(withIdentifier: "MoviesVC", sender: self)
        
        
        
        
        
        saveData()
        self.tblView.reloadData()
    }
    
    
    // delete a row of the table
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            print("going to delete!")
            
            // LOGIC: delete it from DB and ARRAY
            
            // delete it from DB
            //  - do the delete
            myContext.delete(movie[indexPath.row])
            //  - save YOUR CHANGES!!!!!!!!!!!
            saveData()
            
            // delete it from the array
            movie.remove(at: indexPath.row)
            
            // UI: delete it from the tableView
            tblView.deleteRows(at: [indexPath], with: .automatic)
            
        }
        
        
        
        
        
    }
    

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
