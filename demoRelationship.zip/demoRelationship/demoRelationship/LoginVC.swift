//
//  LoginVC.swift
//  demoRelationship
//
//  Created by INDRAVADAN SHRIMALI on 2018-03-19.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {
    
    @IBOutlet weak var tfUsername: UITextField!
    
    @IBOutlet weak var tfPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Login"
        
        // Storing Username and Password in UserDefaults
        let defaults = UserDefaults.standard
        
        defaults.setValue("ias", forKey: "username")
        defaults.setValue("1234", forKey: "password")
        
        
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "background.jpg")!)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func btnLoginTapped(_ sender: UIButton) {
        
        // Getting Username and Password from UserDefaults
        let defaults = UserDefaults.standard
        
        let userName = defaults.object(forKey: "username") as! String
        let password = defaults.object(forKey: "password") as! String
        
        
        
        if (tfUsername.text! != userName || tfPassword.text! != password) {
            
            let alertController = UIAlertController(title: "Alert", message: "Username or Password is Incorrect!!.", preferredStyle: .alert)
            
            let action1 = UIAlertAction(title: "Default", style: .default) { (action:UIAlertAction) in
                print("You've pressed default");
            }
            
            alertController.addAction(action1)
            
            self.present(alertController, animated: true, completion: nil)
            
            
            
        }
            
        else
        {
            
            performSegue(withIdentifier: "ViewController", sender: self)
    }
        
        func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
            
            segue.destination as! ViewController
            
            //        if segue.identifier == "CategoryVC"
            //        {
            //            if segue.destination is CategoryVC {
            //               // destinationVC.numberToDisplay = counter
            //            }
            //        }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
