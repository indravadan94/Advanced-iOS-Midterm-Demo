//
//  Categories+CoreDataProperties.swift
//  demoRelationship
//
//  Created by INDRAVADAN SHRIMALI on 2018-03-18.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//
//

import Foundation
import CoreData


extension Categories {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Categories> {
        return NSFetchRequest<Categories>(entityName: "Categories")
    }

    @NSManaged public var name: String?
    @NSManaged public var movie: Movies?

}
