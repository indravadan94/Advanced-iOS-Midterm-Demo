//
//  Movies+CoreDataProperties.swift
//  demoRelationship
//
//  Created by INDRAVADAN SHRIMALI on 2018-03-18.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//
//

import Foundation
import CoreData


extension Movies {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Movies> {
        return NSFetchRequest<Movies>(entityName: "Movies")
    }

    @NSManaged public var name: String?
    @NSManaged public var isSeen: Bool
    @NSManaged public var category: Categories?

}
