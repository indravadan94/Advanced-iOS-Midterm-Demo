//
//  Movies+CoreDataClass.swift
//  demoRelationship
//
//  Created by INDRAVADAN SHRIMALI on 2018-03-18.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Movies)
public class Movies: NSManagedObject {

}
